<?php

return [
    'navigation_label' => 'État Système',

    'titles' => [
        'widget_title' => 'État Système',
        'cpu_usage' => 'Utilisation CPU',
        'cpu_details' => 'Détails CPU',
        'memory_usage' => 'Utilisation Mémoire',
        'disk_usage' => 'Utilisation Disque',
        'load_average' => 'Charge Moyenne',
        'system_info' => 'Informations Système',
        'uptime' => 'Temps de Fonctionnement du Serveur',
        'performance' => 'Performance',
        'process_info' => 'Informations Processus',
        'cpu_description' => 'Informations CPU en temps réel',
        'memory_description' => 'Statistiques RAM et Mémoire Virtuelle',
        'disk_description' => 'Informations d\'espace disque',
        'system_description' => 'Détails et informations système',
    ],

    'labels' => [
        'os' => 'Système d\'Exploitation',
        'hostname' => 'Nom d\'Hôte',
        'php_version' => 'Version PHP',
        'cores' => 'Cœurs',
        'threads' => 'Threads',
        'cpu_model' => 'Modèle CPU',
        'swap_memory' => 'Mémoire Virtuelle',
        'processes' => 'Processus',
        'running' => 'En Exécution',
        'idle' => 'Inactif',
        'last_reboot' => 'Dernier Redémarrage',
        'mounted_points' => 'Points Montés',
        'inode_usage' => 'Utilisation Inode',
        'memory' => 'Mémoire',
        'used' => 'Utilisée',
        'total' => 'Totale',
        'free' => 'Libre',
        'one_min' => '1 minute',
        'five_min' => '5 minutes',
        'fifteen_min' => '15 minutes',
    ],

    'status' => [
        'excellent' => 'Excellent',
        'good' => 'Bon',
        'warning' => 'Attention',
        'critical' => 'Critique',
        'online' => 'Serveur En Ligne',
        'unavailable' => 'Indisponible',
    ],
];
