<?php

return [
    'navigation_label' => 'Systemstatus',

    'titles' => [
        'widget_title' => 'Systemstatus',
        'cpu_usage' => 'CPU-Nutzung',
        'cpu_details' => 'CPU-Details',
        'memory_usage' => 'Speichernutzung',
        'disk_usage' => 'Festplattennutzung',
        'load_average' => 'Durchschnittliche Last',
        'system_info' => 'Systeminformationen',
        'uptime' => 'Server-Betriebszeit',
        'performance' => 'Leistung',
        'process_info' => 'Prozessinformationen',
        'cpu_description' => 'Echtzeit-CPU-Informationen',
        'memory_description' => 'RAM- und Auslagerungsspeicherstatistiken',
        'disk_description' => 'Festplattenplatzinformationen',
        'system_description' => 'Systemdetails und Informationen',
    ],

    'labels' => [
        'os' => 'Betriebssystem',
        'hostname' => 'Hostname',
        'php_version' => 'PHP-Version',
        'cores' => 'Kerne',
        'threads' => 'Threads',
        'cpu_model' => 'CPU-Modell',
        'swap_memory' => 'Auslagerungsspeicher',
        'processes' => 'Prozesse',
        'running' => 'Wird ausgeführt',
        'idle' => 'Leerlauf',
        'last_reboot' => 'Letzter Neustart',
        'mounted_points' => 'Bereitgestellte Punkte',
        'inode_usage' => 'Inode-Nutzung',
        'memory' => 'Speicher',
        'used' => 'Verwendet',
        'total' => 'Gesamt',
        'free' => 'Frei',
        'one_min' => '1 Minute',
        'five_min' => '5 Minuten',
        'fifteen_min' => '15 Minuten',
    ],

    'status' => [
        'excellent' => 'Ausgezeichnet',
        'good' => 'Gut',
        'warning' => 'Warnung',
        'critical' => 'Kritisch',
        'online' => 'Server Online',
        'unavailable' => 'Nicht Verfügbar',
    ],
];
